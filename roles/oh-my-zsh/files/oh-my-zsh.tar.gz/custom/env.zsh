# Golang
export GO111MODULE=on
export GOPROXY=https://goproxy.io,direct
export GOPATH=$HOME/GoPath

# Java
export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk1.8.0_321.jdk/Contents/Home
#export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-17.0.2.jdk/Contents/Home
export PATH=$PATH:$JAVA_HOME/bin

# Maven
export MAVEN_HOME=/Users/yingzhuo/Softwares/maven
export PATH=$PATH:$MAVEN_HOME/bin

# Gradle
export GRADLE_HOME=/Users/yingzhuo/Softwares/gradle
export PATH=$PATH:$GRADLE_HOME/bin
